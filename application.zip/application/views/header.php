<!DOCTYPE html>
<html>
    <head>
        <title>SOKarma | <? echo $title ?></title>
        <link rel="stylesheet" href="<?php echo base_url("css/layout.css"); ?>">
    </head>
    
    <body>